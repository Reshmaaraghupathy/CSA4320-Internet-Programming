import express from 'express';

const app = express();
const PORT = 5000;

app.get("/all", (req, res) => {
  res.json(hotels);
});

app.get("/search/:name", (req, res) => {
  const name = req.params.name;
  console.log(name);
  const existingHotel = hotels.find(hotel => (hotel.restaurantName).toLowerCase() === name );
  res.json(existingHotel);
});

app.get("/rating/:rating", (req, res) => {
  const rating = parseFloat(req.params.rating);
  const existingHotel = [];
  for(let data of hotels){
    if(data.rating >= rating){
      existingHotel.push(data);
    }
  }
  res.json(existingHotel);
});

app.get("/id/:id", (req, res) => {
  const id = req.params.id;
  const existingHotel = hotels.find(hotel => hotel.id == id);
  res.json(existingHotel);
});

app.listen(5000, () => {
  console.log(`server is running is running at port: ${PORT}`);
});

const hotels = [
    {
      "id": 1,
      "shopName": "Ibaco",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/9/18693619/b4301023adbe8e4b6518f3dfa3d6bafe.png?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.8,
      "exampleCakes": ["Chocolate Truffle", "Butterscotch Delight", "Red Velvet Cake"]
    },
    {
      "id": 2,
      "shopName": "Cake Walk",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/5/65785/cdc3f1f69fc0901984fce7990ca3ebc3.jpg",
      "rating": 4.7,
      "exampleCakes": ["Black Forest Cake", "Pineapple Pastry", "Vanilla Cupcakes"]
    },
    {
      "id": 3,
      "shopName": "Theobroma",
      "shopImage": "https://b.zmtcdn.com/data/pictures/4/20442594/1b718eec5ca7875882e9333c621e1c18.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.9,
      "exampleCakes": ["Brownie Cake", "Opera Cake", "Fresh Fruit Cake"]
    },
    {
      "id": 4,
      "shopName": "Sweet Chariot",
      "shopImage": "https://b.zmtcdn.com/data/pictures/8/18820418/239c813248d5522ee5fffe4c2da93c50.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.5,
      "exampleCakes": ["Carrot Cake", "Plum Cake", "Choco Lava Cake"]
    },
    {
      "id": 5,
      "shopName": "Just Bake",
      "shopImage": "https://b.zmtcdn.com/data/pictures/2/19536002/a8f6eedec66ae8cb91dc9fc171737c43_o2_featured_v2.jpg",
      "rating": 4.6,
      "exampleCakes": ["White Forest Cake", "Mango Mousse Cake", "Raspberry Delight"]
    },
    {
      "id": 6,
      "shopName": "CakeZone",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/9/19490869/f8e158ad74d24f495df1c7103accf9d2.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.7,
      "exampleCakes": ["Hazelnut Chocolate Cake", "Choco Fudge", "Red Velvet Pastry"]
    },
    {
      "id": 7,
      "shopName": "WarmOven",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/5/57215/b7b75b104950eb4367352774a24a1d57.jpeg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.5,
      "exampleCakes": ["KitKat Cake", "Ferrero Rocher Cake", "Cheesecake"]
    },
    {
      "id": 8,
      "shopName": "Monginis",
      "shopImage": "https://b.zmtcdn.com/data/pictures/0/19027920/2352427c1b942f6da7328fc521a324c7_o2_featured_v2.jpg",
      "rating": 4.4,
      "exampleCakes": ["Dutch Truffle", "Eggless Plum Cake", "Rich Chocolate Cake"]
    },
    {
      "id": 9,
      "shopName": "OvenStory",
      "shopImage": "https://b.zmtcdn.com/data/pictures/7/19667147/9cbc4b9af4e62e517d84e10931b66f9d.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.6,
      "exampleCakes": ["Blueberry Cheesecake", "Almond Cake", "Strawberry Tart"]
    },
    {
      "id": 10,
      "shopName": "Cake Studio",
      "shopImage": "https://b.zmtcdn.com/data/pictures/0/19273140/86831c02b3b5d6924f79a1b1f9921d25.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.9,
      "exampleCakes": ["Rainbow Cake", "Coffee Walnut Cake", "Nutella Cake"]
    },
    {
      "id": 11,
      "shopName": "Ferns N Petals",
      "shopImage": "https://b.zmtcdn.com/data/pictures/7/21018657/b713cad77a6683dfb378ea4c0aaad345.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.8,
      "exampleCakes": ["Black Currant Cake", "Vanilla Almond Cake", "Mixed Fruit Cake"]
    },
    {
      "id": 12,
      "shopName": "Delicious Bites",
      "shopImage": "https://b.zmtcdn.com/data/pictures/6/20723506/79a94075ef2f6580023086dcd2100c96.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.7,
      "exampleCakes": ["Oreo Cake", "Layered Chocolate Cake", "Caramel Cake"]
    },
    {
      "id": 13,
      "shopName": "Celebrations Cake Shop",
      "shopImage": "https://b.zmtcdn.com/data/pictures/8/19495498/4752d19f2676efceac7e9f01db6926c6.jpg",
      "rating": 4.5,
      "exampleCakes": ["Tiramisu", "Blueberry Mousse Cake", "Chocolate Mud Cake"]
    },
    {
      "id": 14,
      "shopName": "ChocoFantasy",
      "shopImage": "https://b.zmtcdn.com/data/pictures/5/18386815/7894754f9c893995eef347dc007ee625.jpg",
      "rating": 4.6,
      "exampleCakes": ["Marble Cake", "Nutty Delight", "Choco Chip Cake"]
    },
    {
      "id": 15,
      "shopName": "Happy Bakers",
      "shopImage": "https://b.zmtcdn.com/data/pictures/6/19981046/fd47658ccad0bb3e50ddfbbd903b3a4a.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.7,
      "exampleCakes": ["Almond Praline Cake", "Raspberry Mousse Cake", "Fudge Brownie Cake"]
    },
    {
      "id": 16,
      "shopName": "Brownie Point",
      "shopImage": "https://b.zmtcdn.com/data/pictures/1/19906131/3f77cb2737ac7413a0153a254105720c.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.8,
      "exampleCakes": ["Choco Walnut Cake", "Chocolate Ganache Cake", "Red Velvet Jar Cake"]
    },
    {
      "id": 17,
      "shopName": "La Patisserie",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/6/21161806/1c3ef1b3e8d2ab02c45a40693acbef6d.jpeg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.9,
      "exampleCakes": ["Salted Caramel Cake", "Dark Chocolate Mousse Cake", "Lemon Tart"]
    },
    {
      "id": 18,
      "shopName": "Flour Works",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/2/11882/226e4f1d033058ee2ab52442594aab79.jpg",
      "rating": 4.4,
      "exampleCakes": ["Almond Plum Cake", "Nutty Choco Cake", "Cream Cheese Brownies"]
    },
    {
      "id": 19,
      "shopName": "Dessert Junction",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/5/45765/c6f67a571e5f1bde32228b948cb8fa73.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.6,
      "exampleCakes": ["Peanut Butter Cake", "Choco Mint Cake", "White Choco Cake"]
    },
    {
      "id": 20,
      "shopName": "Baking Dreams",
      "shopImage": "https://b.zmtcdn.com/data/dish_photos/879/dd4e06afb4e3f0123e5fa6a995a7e879.jpeg",
      "rating": 4.7,
      "exampleCakes": ["Nutty Caramel Cake", "Rich Chocolate Brownie", "Vanilla Cupcakes"]
    },
    {
      "id": 21,
      "shopName": "Cupcake Bliss",
      "shopImage": "https://b.zmtcdn.com/data/dish_photos/8f3/60d8e23ccb95980e00a6e138518c78f3.jpeg",
      "rating": 4.5,
      "exampleCakes": ["Vanilla Bean Cake", "Choco Bomb Cake", "Caramel Popcorn Cake"]
    },
    {
      "id": 22,
      "shopName": "The Baking Company",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/4/18388644/60164bbf36c0c002842d21696ecd60d5.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.8,
      "exampleCakes": ["Chocolate Raspberry Cake", "Berry Cheesecake", "Coffee Mocha Cake"]
    },
    {
      "id": 23,
      "shopName": "Dreamy Bakes",
      "shopImage": "https://b.zmtcdn.com/data/pictures/4/20082874/befe9f83ecfdcc079801168de7e50517.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.7,
      "exampleCakes": ["Lemon Drizzle Cake", "Berry Blast Cake", "Marble Cheesecake"]
    },
    {
      "id": 24,
      "shopName": "Cocoa Delights",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/1/19804811/b5bf9589b1224ce2956350a1af6eb011.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.9,
      "exampleCakes": ["Triple Chocolate Cake", "Hazelnut Crunch Cake", "Choco Orange Cake"]
    },
    {
      "id": 25,
      "shopName": "Bake House",
      "shopImage": "https://b.zmtcdn.com/data/pictures/chains/3/19366633/4752d19f2676efceac7e9f01db6926c6.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.6,
      "exampleCakes": ["Strawberry Shortcake", "Molten Lava Cake", "Apple Crumble Cake"]
    },
    {
      "id": 26,
      "shopName": "Golden Oven",
      "shopImage": "https://b.zmtcdn.com/data/pictures/8/18944348/f4f7d75d83ca4fb71e279d900c51408f.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.5,
      "exampleCakes": ["Carrot Walnut Cake", "Choco Swiss Roll", "Banana Toffee Cake"]
    },
    {
      "id": 27,
      "shopName": "Sweet Layers",
      "shopImage": "https://b.zmtcdn.com/data/pictures/3/20979943/36d566dd919d288aaf90c8dcd2805676_o2_featured_v2.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.7,
      "exampleCakes": ["Buttercream Rainbow Cake", "Strawberry Mousse Cake", "Tiramisu Cake"]
    },
    {
      "id": 28,
      "shopName": "Heavenly Treats",
      "shopImage": "https://b.zmtcdn.com/data/pictures/0/20580360/5274ed7f1c589e6dec91af8c56fbc18c.jpg?fit=around|960:500&crop=960:500;*,*",
      "rating": 4.8,
      "exampleCakes": ["Mint Chocolate Cake", "Fruity Delight Cake", "Coconut Cream Cake"]
    },
    {
      "id": 29,
      "shopName": "Bakeology",
      "shopImage": "https://b.zmtcdn.com/data/pictures/0/20669010/20490f8d3a228ec64c5547e00c03b404.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.9,
      "exampleCakes": ["Dark Forest Cake", "Lemon Meringue Cake", "Strawberry Cheesecake"]
    },
    {
      "id": 30,
      "shopName": "Sweet Escape",
      "shopImage": "https://b.zmtcdn.com/data/pictures/5/21534255/b8fe043e609d483fb2c3ff04750930d4.jpg?fit=around|750:500&crop=750:500;*,*",
      "rating": 4.8,
      "exampleCakes": ["Peach Cobbler Cake", "Cherry Blossom Cake", "White Chocolate Raspberry Cake"]
    }
  ];
