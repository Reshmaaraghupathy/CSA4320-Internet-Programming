import express from "express";

const app = express();
const PORT = 4000;

function shuffleArray(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
        const randomIndex = Math.floor(Math.random() * (i + 1));
        
        [arr[i], arr[randomIndex]] = [arr[randomIndex], arr[i]];
    }
    return arr;
}

app.get("/random/getmenu", (req, res) => {
    const result = shuffleArray(menu);
    res.json(result);
});

app.get("/cake/:id", (req, res) => {
    const id = req.params.id;
    const result = menu.find(cake => cake.id == id);
    res.json(result);
});

app.listen(PORT, () => {
    console.log(`Server is running at port: ${PORT}`);
});

const menu = [
    {
        "id": 1,
        "name": "Chocolate Lava Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/e15/6ff0018114cd37750fac5047f5888e15.jpeg",
        "rating": 4.5,
        "cost": 1200,
        "content": "A rich and gooey chocolate cake with molten chocolate flowing from the center, served warm."
    },
    {
        "id": 2,
        "name": "Vanilla Bean Cake",
        "image": "https://b.zmtcdn.com/data/pictures/6/20014246/aca1931494463f5f69a51a3edf939012.jpg?fit=around|960:500&crop=960:500;*,*",
        "rating": 4.2,
        "cost": 900,
        "content": "A soft and moist vanilla cake infused with the rich aroma of real vanilla beans."
    },
    {
        "id": 3,
        "name": "Red Velvet Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/832/df9b85e1e1ae11be54c2749aa6b33832.jpg",
        "rating": 4.7,
        "cost": 1500,
        "content": "A velvety smooth red cake with a subtle cocoa flavor, topped with a luxurious cream cheese frosting."
    },
    {
        "id": 4,
        "name": "Carrot Cake",
        "image": "https://thecococompany.com/cdn/shop/products/IMG_8086.jpg?v=1645617212&width=480",
        "rating": 4.8,
        "cost": 1400,
        "content": "A moist carrot cake with a perfect balance of sweetness and spice, topped with a creamy frosting."
    },
    {
        "id": 5,
        "name": "Lemon Drizzle Cake",
        "image": "https://b.zmtcdn.com/data/pictures/7/20931617/4ddd0b2bc366085c447c9a1cb81b80c6.png",
        "rating": 4.3,
        "cost": 1100,
        "content": "A refreshing and zesty lemon cake drizzled with a tangy lemon glaze for a burst of flavor."
    },
    {
        "id": 6,
        "name": "Strawberry Shortcake",
        "image": "https://b.zmtcdn.com/data/dish_photos/cb5/1ad21c7ca7d0a6895c22c8a3d5ee4cb5.jpg",
        "rating": 4.6,
        "cost": 1300,
        "content": "Fluffy sponge cake layers with fresh strawberries and whipped cream, a classic favorite."
    },
    {
        "id": 7,
        "name": "Coffee Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/007/19292e18b114587b57a39f76c23a5007.jpeg",
        "rating": 4.0,
        "cost": 950,
        "content": "A perfectly baked cake with a coffee-flavored base and a crumbly, sugary topping."
    },
    {
        "id": 8,
        "name": "Pineapple Upside Down Cake",
        "image": "https://www.milkmaid.in/sites/default/files/2023-09/Pineapple-Upside-down-cake-iStock-1369184674-335x300.jpg",
        "rating": 4.4,
        "cost": 1200,
        "content": "Caramelized pineapple and a moist cake base create a delightful and tangy treat."
    },
    {
        "id": 9,
        "name": "Banana Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/5e4/e76f98413aeb577be8fde8a980b2d5e4.jpeg",
        "rating": 4.1,
        "cost": 1100,
        "content": "A soft banana-flavored cake that’s both sweet and indulgent, with a melt-in-your-mouth texture."
    },
    {
        "id": 10,
        "name": "Chocolate Mousse Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/b95/dab6ea78999b82088a91004f02a6ab95.png",
        "rating": 4.9,
        "cost": 1700,
        "content": "A decadent chocolate mousse encased in a rich, dark chocolate shell, a dream for chocolate lovers."
    },
    {
        "id": 11,
        "name": "Coconut Cake",
        "image": "https://b.zmtcdn.com/data/pictures/chains/4/19832544/cb00f1cfdd91d47986766f0032cdbc69.jpg",
        "rating": 4.3,
        "cost": 1350,
        "content": "A fluffy coconut cake with a delicate flavor, topped with a creamy coconut frosting."
    },
    {
        "id": 12,
        "name": "Marble Cake",
        "image": "https://www.shreemithai.com/cdn/shop/products/chocolate-marble-cake-749287.jpg?v=1707819784&width=1200",
        "rating": 4.2,
        "cost": 1000,
        "content": "A beautiful blend of chocolate and vanilla, creating a rich and swirled cake with an elegant look."
    },
    {
        "id": 13,
        "name": "Pumpkin Spice Cake",
        "image": "https://b.zmtcdn.com/data/pictures/5/20576835/bec655cf9f346a6c91d9f90ddaefaac5_o2_featured_v2.jpg",
        "rating": 4.4,
        "cost": 1100,
        "content": "A warm, spiced pumpkin cake perfect for the fall season, with a touch of cinnamon and nutmeg."
    },
    {
        "id": 14,
        "name": "Chocolate Cheesecake",
        "image": "https://b.zmtcdn.com/data/dish_photos/0b8/76a99a6ec056fbb37939c2aaf96d50b8.jpg",
        "rating": 4.8,
        "cost": 1600,
        "content": "A rich and creamy cheesecake with a smooth chocolate flavor, set on a crunchy biscuit crust."
    },
    {
        "id": 15,
        "name": "Tiramisu Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/df4/56308f6d20273e583acaf09c41f0edf4.jpeg",
        "rating": 4.5,
        "cost": 1500,
        "content": "A luscious blend of mascarpone cheese, coffee-soaked ladyfingers, and cocoa powder, in a cake form."
    },
    {
        "id": 16,
        "name": "Raspberry Cheesecake",
        "image": "https://b.zmtcdn.com/data/dish_photos/6ec/1617b0ae33fd5a58995bc4084461e6ec.jpeg",
        "rating": 4.6,
        "cost": 1700,
        "content": "A silky smooth cheesecake with a tart raspberry topping and a buttery graham cracker crust."
    },
    {
        "id": 17,
        "name": "Peach Melba Cake",
        "image": "https://prd-upmarket.s3.ap-south-1.amazonaws.com/AA0013/generated/ar1x1/large/PM1kgstyled-Large.jpg",
        "rating": 4.3,
        "cost": 1250,
        "content": "A fruity peach-flavored cake, layered with raspberry sauce and fresh peaches."
    },
    {
        "id": 18,
        "name": "Apple Cinnamon Cake",
        "image": "https://www.amritas.co.in/cdn/shop/products/MG_0158_Fotor.jpg?v=1602851680",
        "rating": 4.2,
        "cost": 1100,
        "content": "A warm, comforting apple and cinnamon cake with a soft, spongy texture."
    },
    {
        "id": 19,
        "name": "Mango Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/6f6/4d614b3bb5e2c671ae7fd7b108cb96f6.jpg",
        "rating": 4.7,
        "cost": 1450,
        "content": "A tropical cake made with fresh mangoes, giving it a refreshing and sweet flavor."
    },
    {
        "id": 20,
        "name": "Hazelnut Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/c2f/b5be5116e1eab304b9044878cdeb1c2f.jpg",
        "rating": 4.4,
        "cost": 1550,
        "content": "A rich hazelnut cake with a creamy hazelnut spread filling and a crunchy top."
    },
    {
        "id": 21,
        "name": "Baked Alaska",
        "image": "https://b.zmtcdn.com/data/pictures/7/2201417/cbab50f52f391e3dd3af96a383b6661f_featured_v2.jpg",
        "rating": 4.6,
        "cost": 2000,
        "content": "A perfect blend of vanilla cake, meringue, and ice cream, toasted to perfection."
    },
    {
        "id": 22,
        "name": "Churros Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/9b3/811e3a51763eefdfdeb1a43dddfac9b3.jpg",
        "rating": 4.3,
        "cost": 1300,
        "content": "A cake inspired by churros, with a cinnamon-sugar flavor and a crispy finish."
    },
    {
        "id": 23,
        "name": "Cherry Blossom Cake",
        "image": "https://b.zmtcdn.com/data/pictures/chains/2/19193712/67c984eda054f3107a3d0dd926523ce7.jpg",
        "rating": 4.7,
        "cost": 1450,
        "content": "A delicate cherry-flavored cake with a light, airy texture, adorned with fresh cherries."
    },
    {
        "id": 24,
        "name": "Mochi Cake",
        "image": "https://b.zmtcdn.com/data/pictures/1/19400681/f7e3b4a69372c928b249591d16a09827.jpg?fit=around|960:500&crop=960:500;*,*",
        "rating": 4.5,
        "cost": 1200,
        "content": "A soft, chewy cake made from glutinous rice flour, infused with sweet flavors."
    },
    {
        "id": 25,
        "name": "Pistachio Cake",
        "image": "https://b.zmtcdn.com/data/pictures/9/20847379/b2cb2701bbcbc050d8f2297b1a287ac4_o2_featured_v2.jpg?fit=around|750:500&crop=750:500;*,*",
        "rating": 4.4,
        "cost": 1500,
        "content": "A nutty pistachio cake with a rich flavor and a smooth, creamy frosting."
    },
    {
        "id": 26,
        "name": "S'mores Cake",
        "image": "https://b.zmtcdn.com/data/pictures/chains/1/19506931/4fe31dcdd8c7acdb991f882ea6f56c88.jpg?fit=around|750:500&crop=750:500;*,*",
        "rating": 4.8,
        "cost": 1600,
        "content": "A cake inspired by the classic campfire treat, with layers of chocolate, graham crackers, and marshmallows."
    },
    {
        "id": 27,
        "name": "Nutella Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/c32/c460d30a02de89a0d22250654b7f2c32.jpg",
        "rating": 4.9,
        "cost": 1700,
        "content": "A chocolate cake layered with rich Nutella spread and topped with hazelnuts."
    },
    {
        "id": 28,
        "name": "Tropical Fruit Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/5c8/306c1d874cf4ad11927b572b9287e5c8.jpg",
        "rating": 4.6,
        "cost": 1400,
        "content": "A cake bursting with tropical fruits like pineapple, coconut, and mango, for a refreshing flavor."
    },
    {
        "id": 29,
        "name": "Zucchini Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/402/07c56f5f511f0d295e459a55be124402.jpeg",
        "rating": 4.1,
        "cost": 1100,
        "content": "A moist and lightly spiced cake made with zucchini, giving it a unique flavor and texture."
    },
    {
        "id": 30,
        "name": "Fudge Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/879/dd4e06afb4e3f0123e5fa6a995a7e879.jpeg",
        "rating": 4.7,
        "cost": 1450,
        "content": "A rich and fudgy chocolate cake with a gooey, melt-in-your-mouth texture."
    },
    {
        "id": 31,
        "name": "Matcha Green Tea Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/5eb/20dd1e5153a2ca65c377c8ac5cd165eb.jpg",
        "rating": 4.5,
        "cost": 1600,
        "content": "A fragrant matcha-flavored cake with a delicate balance of earthy and sweet notes."
    },
    {
        "id": 32,
        "name": "Coconut Lime Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/109/8cdcfec898603944ddacf086bde38109.jpg",
        "rating": 4.3,
        "cost": 1350,
        "content": "A tropical combination of coconut and lime, creating a refreshing cake with a zesty kick."
    },
    {
        "id": 33,
        "name": "Black Forest Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/28c/3ca18a7a51161d4f911c79974c59c28c.jpg",
        "rating": 4.8,
        "cost": 1800,
        "content": "A classic chocolate cake layered with whipped cream and cherries, with a hint of brandy."
    },
    {
        "id": 34,
        "name": "Biscuit Cake",
        "image": "https://b.zmtcdn.com/data/pictures/8/37088/7021048870b436bf521eab862dcd3248.jpg?fit=around|960:500&crop=960:500;*,*",
        "rating": 4.2,
        "cost": 1000,
        "content": "A cake made with layers of biscuits soaked in chocolate syrup, giving it a unique flavor."
    },
    {
        "id": 35,
        "name": "Honey Cake",
        "image": "https://b.zmtcdn.com/data/pictures/chains/7/20016377/edd93dde619eb2bc58710a7e94a91b8c.jpg",
        "rating": 4.6,
        "cost": 1200,
        "content": "A fragrant cake made with honey, giving it a soft texture and a naturally sweet flavor."
    },
    {
        "id": 36,
        "name": "Almond Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/585/767ba558f0b808a4bc1f58f6d247e585.png",
        "rating": 4.7,
        "cost": 1400,
        "content": "A cake with the delicate flavor of almonds, topped with a layer of marzipan for extra sweetness."
    },
    {
        "id": 37,
        "name": "Choco Mint Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/a53/18c696fa1421cbae87fe1be2dae9ca53.jpeg",
        "rating": 4.4,
        "cost": 1300,
        "content": "A chocolate cake with a refreshing mint flavor, topped with a mint-chocolate frosting."
    },
    {
        "id": 38,
        "name": "Cherry Almond Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/120/04f9f94acdb0d2963ddfb54b1d320120.jpeg",
        "rating": 4.6,
        "cost": 1550,
        "content": "A perfect pairing of sweet cherries and almond flavor, topped with a cherry glaze."
    },
    {
        "id": 39,
        "name": "Apricot Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/4a0/b82bffa613b43582c988b419e2bcf4a0.jpeg",
        "rating": 4.5,
        "cost": 1250,
        "content": "A soft and fruity cake made with apricots, giving it a naturally sweet and tangy flavor."
    },
    {
        "id": 40,
        "name": "Saffron Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/a86/289e679bb5be6fe4046b19466e988a86.jpg",
        "rating": 4.8,
        "cost": 1800,
        "content": "A luxurious cake infused with the aromatic flavor of saffron, perfect for special occasions."
    },
    {
        "id": 41,
        "name": "Peach Cobbler Cake",
        "image": "https://baranbakery.com/wp-content/uploads/2022/08/Peach-Cobbler-Pound-Cake-12.jpg",
        "rating": 4.6,
        "cost": 1500,
        "content": "A moist cake layered with juicy peaches, topped with a buttery crumble for a cobbler-like texture."
    },
    {
        "id": 42,
        "name": "Lemon Poppy Seed Cake",
        "image": "https://bojongourmet.com/wp-content/uploads/2023/01/gluten-free-lemon-poppy-seed-cake-17.jpg",
        "rating": 4.5,
        "cost": 1350,
        "content": "A light and zesty lemon cake sprinkled with poppy seeds, perfect for a fresh burst of flavor."
    },
    {
        "id": 43,
        "name": "Raspberry Almond Cake",
        "image": "https://b.zmtcdn.com/data/pictures/5/21079785/c91a7557acd9fc889d6bfa0d49e2a97b.jpg?fit=around|750:500&crop=750:500;*,*",
        "rating": 4.7,
        "cost": 1450,
        "content": "A delicate almond-flavored cake filled with tangy raspberries, providing a perfect sweet-sour balance."
    },
    {
        "id": 44,
        "name": "Strawberry Shortcake",
        "image": "https://b.zmtcdn.com/data/dish_photos/cb5/1ad21c7ca7d0a6895c22c8a3d5ee4cb5.jpg",
        "rating": 4.8,
        "cost": 1600,
        "content": "A fluffy cake layered with fresh strawberries and whipped cream, creating a classic dessert experience."
    },
    {
        "id": 45,
        "name": "Mocha Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/bd8/da08869ed4a609a1d37beb30d0011bd8.png",
        "rating": 4.5,
        "cost": 1700,
        "content": "A rich coffee-flavored cake with a hint of chocolate, perfect for coffee lovers."
    },
    {
        "id": 46,
        "name": "Carrot Pecan Cake",
        "image": "https://thesaltandsweet.com/wp-content/uploads/2022/11/wp-1668486032539-720x720.jpg",
        "rating": 4.6,
        "cost": 1450,
        "content": "A moist carrot cake with chopped pecans, topped with a rich cream cheese frosting."
    },
    {
        "id": 47,
        "name": "Pumpkin Spice Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/6b5/6b02386aff65dee4287b29cd61e7f6b5.jpg",
        "rating": 4.7,
        "cost": 1500,
        "content": "A spiced pumpkin cake that’s perfect for fall, with hints of cinnamon and nutmeg."
    },
    {
        "id": 48,
        "name": "Red Velvet Cheesecake",
        "image": "https://b.zmtcdn.com/data/dish_photos/43e/bd33a595b7f6385af7b929c1771cb43e.jpg",
        "rating": 4.9,
        "cost": 1800,
        "content": "A velvety red velvet cake topped with a rich and creamy cheesecake layer, creating a luxurious dessert."
    },
    {
        "id": 49,
        "name": "Lemon Meringue Cake",
        "image": "https://b.zmtcdn.com/data/dish_photos/61e/afddce1f729fca2c32647cf39cf4261e.jpeg",
        "rating": 4.6,
        "cost": 1550,
        "content": "A light and tangy lemon cake topped with fluffy meringue for a refreshing dessert."
    },
    {
        "id": 50,
        "name": "Banana Foster Cake",
        "image": "https://www.allrecipes.com/thmb/ncUHbfxq5vk5eKU0VT0_a9GB_-E=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/banana-fosters-cake-Step-006-1-720a9f7b0b0c4487abb470ab802c0814.jpg",
        "rating": 4.8,
        "cost": 1600,
        "content": "A banana cake with a rich rum sauce, inspired by the classic banana foster dessert."
    }
]
