import bodyParser from "body-parser";
import express from "express";
import pg from "pg";
import axios from "axios";

const db = new pg.Client({
    user: 'postgres',
    host: 'localhost',
    database: 'zomato clone',
    password: 'roomi@456',
    port: '5432'
});

db.connect((err) => {
    if (err) {
        console.log("Error in connecting to the database:", err.message);
    } else {
        console.log("Successfully connected to the database");
    }
});

const API_URL = "http://localhost:5000";

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let currentUser = 1;

async function getCurrentUser(email){
    try {
        const result = await db.query("SELECT * FROM user_details WHERE email = $1", [email]);
        currentUser = result.rows[0].id;
    } catch (error) {
        console.log("email dosen't exist");
        console.log("error in fetching the data");
    }
};

async function getUserDetails(){
    const result = await db.query("SELECT * FROM user_details WHERE id = $1", [currentUser]);
    const details = result.rows[0];
    return details;
};

app.get("/", (req, res) => {
    res.render("login.ejs");
});

app.post("/login", async (req, res) => {
    const enteredEmail = req.body.email;
    const enteredPassword = req.body.password;
    try {
        const result = await db.query("SELECT * FROM user_details WHERE email = $1", [enteredEmail]);
        if (result.rows.length > 0 && enteredPassword === result.rows[0].password) {
            getCurrentUser(enteredEmail);
            res.redirect("/home");
        } else {
            res.render("login.ejs", { errorMessage: "Invalid email or password" });
        }
    } catch (err) {
        console.log("Error during login:", err.message);
        res.render("login.ejs", { errorMessage: "An error occurred. Please try again." });
    }
});

app.get("/register", (req, res) => {
    res.render("register.ejs");
});

app.post("/register", async (req, res) => {
    const { password, name, email, phone } = req.body;
    const rePassword = req.body['confirm-password'];
    if (password.length >= 8) {
        if (password === rePassword) {
            try {
                const result = await db.query(
                    "INSERT INTO user_details(name, email, contact, password) VALUES($1, $2, $3, $4) RETURNING id",
                    [name, email, phone, password]
                );
                currentUser = result.rows[0].id;
                res.redirect("/home");
            } catch (err) {
                console.log("Error during registration:", err.message);
                res.render("register.ejs", { errorMessage: "Something went wrong. Please try again." });
            }
        } else {
            res.render("register.ejs", { errorMessage: "Password mismatch" });
        }
    } else {
        res.render("register.ejs", { errorMessage: "Password must be at least 8 characters" });
    }
});

app.get("/home", async (req, res) => {
    try {
        const details = await getUserDetails();
        const result = await axios.get(API_URL + "/all");
        const restaurants = result.data;
        res.render("home.ejs", { restaurants: restaurants, userName: details.name });
    } catch (err) {
        console.error("Error loading home page:", err.message);
        res.render("home.ejs", { errorMessage: "Unable to load data" });
    }
});

app.post("/home", async (req, res) => {
    try {
        const searchInput = req.body.query;
        const result = await axios.get(API_URL + `/search`, {});
        const restaurants = result.data;
        res.render("home.ejs", { restaurants: restaurants });
    } catch (error) {
        console.log("err", error);
        res.redirect("/home");
    }
});

app.get("/contact", async (req, res) => {
    const details = await getUserDetails();
    res.render("contact.ejs", { userName: details.name });
});

app.get("/about", async (req, res) => {
    const details = await getUserDetails();
    res.render("about.ejs", { userName: details.name });
});

app.get("/account", async (req, res) => {
    const details = await getUserDetails();
    res.render("account.ejs", { userName: details.name, name: details.name, email: details.email, phone: details.contact });
});

const allowedFields = ['name', 'email', 'phone']; 

app.post("/account", async (req, res) => {
    const updatedDetails = req.body;
    if (allowedFields.includes(updatedDetails.field)) {
        if (updatedDetails.field === 'phone') {
            await db.query("UPDATE user_details SET contact = $1 WHERE id = $2", [updatedDetails.value, currentUser]);
        } else {
            await db.query(`UPDATE user_details SET ${updatedDetails.field} = $1 WHERE id = $2`, [updatedDetails.value, currentUser]);
        }
        res.status(200).send({ message: "Profile updated successfully" });
    } else {
        res.status(400).send({ error: "Invalid field name" });
    }
});

app.get("/menus", async (req, res) => {
    const details = await getUserDetails();
    try {
        const result = await axios.get("http://localhost:4000/random/getmenu");
        res.render("menus.ejs", { menuDetails: result.data, userName: details.name });
    } catch (error) {
        console.log(error);
        res.redirect("/home");
    }
});

app.post("/menus", async (req, res) => {
    const result = req.body;
    console.log(result);
    const cakeId = parseInt(result.cakeId);
    const quantity = parseInt(result.quantity);
    const user_id = parseInt(currentUser);

    if (!cakeId || !quantity || quantity <= 0 || !user_id) {
        console.log("Invalid input data");
        return res.redirect("/menus");
    }

    try {
        await db.query("INSERT INTO cart(cake_id, quantity, user_id) VALUES($1, $2, $3)", [cakeId, quantity, user_id]);
        console.log("success");
        res.redirect("/menus");
    } catch (error) {
        console.log("There is an error in inserting");
        res.redirect("/menus");
    }
});

app.get("/cart", async (req, res) => {
    try {
        const details = await getUserDetails();
        const result = await db.query(
            "SELECT * FROM user_details JOIN cart ON user_details.id = cart.user_id WHERE user_details.id = $1",
            [currentUser]
        );
        const data = result.rows;

        const cakeDetails = await Promise.all(
            data.map(async (item, index) => {
                try {
                    const response = await fetch(`http://localhost:4000/cake/${item.cake_id}`);
                    const cake = await response.json();
                    return { ...item, cake }; 
                } catch (error) {
                    console.error(`Error fetching details for cake_id ${item.cake_id}:`, error);
                    return { ...item, cake: null }; 
                }
            })
        );
        console.log(cakeDetails);
        res.render("cart.ejs", { cartItems: cakeDetails, userName: details.name });
    } catch (error) {
        console.error("Error in /cart handler:", error);
        res.status(500).send("An error occurred while processing the request");
    }
});



app.listen(3000, () => {
    console.log("Server is running on http://localhost:3000");
});
